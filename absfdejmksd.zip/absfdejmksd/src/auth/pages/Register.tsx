import React, { ChangeEvent, useState } from 'react';
import { Select, MenuItem, FormControl, InputLabel } from '@material-ui/core';
import Box from "@material-ui/core/Box";
import Button from "@material-ui/core/Button";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import TextField from "@material-ui/core/TextField";
import Typography from "@material-ui/core/Typography";
import LoadingButton from "@material-ui/lab/LoadingButton";
import { useFormik } from "formik";
import { useTranslation } from "react-i18next";
import { Link, useNavigate } from "react-router-dom";
import * as Yup from "yup";
import BoxedLayout from "../../core/components/BoxedLayout";
import { useSnackbar } from "../../core/contexts/SnackbarProvider";
import { useRegister } from "../hooks/useRegister";
import { UserInfo } from "../types/userInfo";


const genders = [
  { label: "auth.register.form.gender.options.f", value: "F" },
  { label: "auth.register.form.gender.options.m", value: "M" },
  { label: "auth.register.form.gender.options.n", value: "NC" },
];

const Register = () => {

  const navigate = useNavigate();
  const snackbar = useSnackbar();
  const { t } = useTranslation();

  const { isRegistering, register } = useRegister();

  interface IProps {
    states: Record<string, string[]>;
    cities: Record<string, string[]>;
  }

  const [firstname, setFirstname] = useState<string>('');
  const [lastname, setLastname] = useState<string>('');
  const [username, setUsername] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [cpassword, setCpass] = useState<string>('');
  const [phoneno, setphoneno] = useState<string>('');
  const [dob, setDob] = useState<string>('');
  const [gender, setGender] = useState<string>('');
  const [country, setCountry] = useState<string>('');
  const [state, setState] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [qualification, setQualification] = useState([]);
  const [programmingskills, setProgramingskill] = useState([]);
  // const [error, setError] = useState<string>('');

  // const [firstnameerror, setFirstNameError] = useState<string>('');
  // const [lastnameerror, setLastNameError] = useState<string>('');


  const handleCountryChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setCountry(event.target.value);
    setState('');
    setCity('');
  };

  const handleStateChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setState(event.target.value);
    setCity('');
  };

  const handleCityChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setCity(event.target.value);
  };

  const states = {
    India: ["Maharashtra", "Karnataka", "Tamil Nadu"],
    US: ["New York", "California", "Texas"],
  };

  const cities = {
    "New York": ["New York City", "Buffalo"],
    California: ["Los Angeles", "San Francisco"],
    Texas: ["Houston", "Dallas"],
    Maharashtra: ["Mumbai", "Pune"],
    Karnataka: ["Bangalore", "Mysore"],
    "Tamil Nadu": ["Chennai", "Coimbatore"],
  };




  interface FormState {
    btech: boolean;
    mtech: boolean;
  }

  const [formState, setFormState] = useState<FormState>({
    btech: false,
    mtech: false
  });

  const qualificationHandleChange = (event: ChangeEvent<HTMLInputElement>): void => {
    const { name, checked } = event.target;
    setFormState(prevState => ({ ...prevState, [name]: checked }));
  };


  interface Option {
    label: string;
    value: string;
  }

  const options: Option[] = [
    { label: 'Nodejs', value: 'Nodejs' },
    { label: 'Reactjs', value: 'Reactjs' },
    { label: 'Express', value: 'Express' },
    { label: 'Angular', value: 'Angular' },
  ];
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);

  const handleSelectChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    const values = event.target.value as string[];
    setSelectedOptions(values);

  };

  const formik = useFormik({
    initialValues: {
      email: "",
      firstName: "",
      gender: "F",
      lastName: "",
      username: "",
      phoneno: "",
      password: "",
      cpassword: "",
      dob: "",
      country: "",
      state: "",
      city: "",
      address: "",
      qualification: "",
      programmingskills: "",
      profile: ""

    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email address")
        .required(t("common.validations.required")),
      firstName: Yup.string()
        .max(20, t("common.validations.max", { size: 20 }))
        .required(t("common.validations.required")),
      lastName: Yup.string()
        .max(30, t("common.validations.max", { size: 30 }))
        .required(t("common.validations.required")),
      username: Yup.string()
        .max(30, t("common.validations.max", { size: 10 }))
        .required(t("common.validations.required")),
      phoneno: Yup.string()
        .max(30, t("common.validations.max", { size: 10 }))
        .required(t("common.validations.required")),
      password: Yup.string()
        .max(30, t("common.validations.max", { size: 10 }))
        .required(t("common.validations.required")),
      cpassword: Yup.string()
        .max(30, t("common.validations.max", { size: 10 }))
        .required(t("common.validations.required")),
    }),
    onSubmit: (values) => handleRegister(values),
  });

  
  const formData = {
    email,
    firstname,
    lastname,
    username,
    phoneno,
    password,
    cpassword,
    gender,
    dob,
    country,
    state,
    city,
    address,
    qualification,
    programmingskills,
    // profile: profileFile,
  };
  const handleRegister = async (values: Partial<UserInfo>) => {
   

        const response = await fetch("http://localhost:2025/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });
        
        if (response.status == 200) {
          navigate('/login')
      }
       console.log(formData)

      }

  return (
    <BoxedLayout>
      <Typography component="h1" variant="h5">
        {t("auth.register.title")}
      </Typography>
      <Box
        component="form"
        marginTop={3}
        noValidate
        onSubmit={formik.handleSubmit}
      >
        <TextField
          margin="normal"
          required
          fullWidth
          id="firstName"
          label={t("auth.register.form.firstName.label")}
          name="firstName"
          autoComplete="given-name"
          disabled={isRegistering}
          value={formik.values.firstName}
          onChange={formik.handleChange}
          error={formik.touched.firstName && Boolean(formik.errors.firstName)}
          helperText={formik.touched.firstName && formik.errors.firstName}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          id="lastName"
          label={t("auth.register.form.lastName.label")}
          name="lastName"
          autoComplete="family-name"
          autoFocus
          disabled={isRegistering}
          value={formik.values.lastName}
          onChange={formik.handleChange}
          error={formik.touched.lastName && Boolean(formik.errors.lastName)}
          helperText={formik.touched.lastName && formik.errors.lastName}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          id="email"
          label={t("auth.register.form.email.label")}
          name="email"
          autoComplete="email"
          disabled={isRegistering}
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.touched.email && Boolean(formik.errors.email)}
          helperText={formik.touched.email && formik.errors.email}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          id="username"
          // label={t("auth.register.form.username.label")}
          name="username"
          autoComplete="given-name"
          placeholder="Username*"
          disabled={isRegistering}
          value={formik.values.username}
          onChange={formik.handleChange}
          error={formik.touched.username && Boolean(formik.errors.username)}
          helperText={formik.touched.username && formik.errors.username}
        />

        <TextField
          margin="normal"
          required
          fullWidth
          id="phoneno"
          type="number"
          // label={t("auth.register.form.username.label")}
          name="phoneno"
          autoComplete="given-name"
          placeholder="Phoneno*"
          disabled={isRegistering}
          value={formik.values.phoneno}
          onChange={formik.handleChange}
          error={formik.touched.phoneno && Boolean(formik.errors.phoneno)}
          helperText={formik.touched.phoneno && formik.errors.phoneno}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          id="password"
          type="password"
          // label={t("auth.register.form.username.label")}
          name="password"
          autoComplete="given-name"
          placeholder="password*"
          disabled={isRegistering}
          value={formik.values.password}
          onChange={formik.handleChange}
          error={formik.touched.password && Boolean(formik.errors.password)}
          helperText={formik.touched.password && formik.errors.password}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          id="cpassword"
          type="password"
          // label={t("auth.register.form.username.label")}
          name="cpassword"
          autoComplete="given-name"
          placeholder="cpassword*"
          disabled={isRegistering}
          value={formik.values.cpassword}
          onChange={formik.handleChange}
          error={formik.touched.cpassword && Boolean(formik.errors.cpassword)}
          helperText={formik.touched.cpassword && formik.errors.cpassword}
        />

        <TextField
          margin="normal"
          required
          fullWidth
          id="dob"
          type="date"
          // label={t("auth.register.form.username.label")}
          name="dob"
          autoComplete="given-name"
          placeholder="dob*"
          disabled={isRegistering}
          value={formik.values.dob}
          onChange={formik.handleChange}
          error={formik.touched.dob && Boolean(formik.errors.dob)}
          helperText={formik.touched.dob && formik.errors.dob}
        />



        <TextField
          margin="normal"
          required
          fullWidth
          id="address"
          type="text"
          // label={t("auth.register.form.username.label")}
          name="address"
          autoComplete="given-name"
          placeholder="Address*"
          disabled={isRegistering}
          value={formik.values.address}
          onChange={formik.handleChange}
          error={formik.touched.address && Boolean(formik.errors.address)}
          helperText={formik.touched.address && formik.errors.address}
        />
        <FormControl component="fieldset" margin="normal">
          <FormLabel component="legend">
            {t("auth.register.form.gender.label")}
          </FormLabel>
          <RadioGroup
            row
            aria-label="gender"
            name="gender"
            value={formik.values.gender}
            onChange={formik.handleChange}
          >
            {genders.map((gender) => (
              <FormControlLabel
                control={<Radio />}
                key={gender.value}
                disabled={isRegistering}
                label={t(gender.label)}
                value={gender.value}
              />
            ))}
          </RadioGroup>
        </FormControl>
        <br />
        <div className="input-block" >
          <label htmlFor="country">Country</label>
          <select id="country" value={country} onChange={handleCountryChange}>
            <option value="">Select a country</option>
            <option value="US">United States</option>
            <option value="India">India</option>
          </select>
          <br></br>

          <label htmlFor="state">State</label>
          <select id="state" value={state} onChange={handleStateChange} disabled={!country}>
            <option value="">Select a state</option>
            {states[country] &&
              states[country].map((state) => (
                <option key={state} value={state}>
                  {state}
                </option>
              ))}
          </select>
          <br></br>
          <label htmlFor="city">City</label>
          <select id="city" value={city} onChange={handleCityChange} disabled={!state}>
            <option value="">Select a city</option>
            {cities[state] &&
              cities[state].map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
          </select>
        </div>

        <br />
        <div className="input-block">
          <label htmlFor="qualification" className="input-label">
            Qualification
          </label>
          <div>
            <input
              type="checkbox"
              autoComplete="off"
              name="btech"
              id="btech"
              value="btech"
              checked={formState.btech}
              onChange={qualificationHandleChange}
            />
            <label htmlFor="btech">BTech</label>
          </div>

          <div>
            <input
              type="checkbox"
              autoComplete="off"
              name="mtech"
              id="mtech"
              value="mtech"
              checked={formState.mtech}
              onChange={qualificationHandleChange}
            />
            <label htmlFor="mtech">MTech</label>
          </div>
        </div>
        <br />
        <FormControl>
          <InputLabel id="select-multiple-label">Select  options</InputLabel> <br />
          <Select
            labelId="select-multiple-label"
            id="select-multiple"
            multiple
            value={selectedOptions}
            onChange={handleSelectChange}
          >
            {options.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <LoadingButton
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
          disabled={isRegistering}
          loading={isRegistering}
          sx={{ mt: 2 }}
        >
          {t("auth.register.submit")}
        </LoadingButton>
        <Button
          component={Link}
          to={`/${process.env.PUBLIC_URL}/login`}
          color="primary"
          fullWidth
          sx={{ mt: 2 }}
        >
          {t("auth.register.back")}
        </Button>
      </Box>
    </BoxedLayout>
  );
};

export default Register;
