const shape = {
  borderRadius: 16,
};

export default shape;
