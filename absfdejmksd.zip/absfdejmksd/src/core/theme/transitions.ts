const transitions = {
  duration: {
    shortest: 75,
    shorter: 100,
    short: 125,
    standard: 150,
    complex: 175,
    enteringScreen: 115,
    leavingScreen: 95,
  },
};

export default transitions;
