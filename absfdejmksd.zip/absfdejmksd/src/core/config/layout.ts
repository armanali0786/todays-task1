export const drawerCollapsedWidth = 104;
export const drawerWidth = 280;
