export const notificationKeys: { [key: string]: string } = {
  newComment: "notifications.newComment",
  unreadMessages: "notifications.unreadMessages",
};
